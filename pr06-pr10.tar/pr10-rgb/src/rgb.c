#include <stdio.h>

int main(){
	int r,g,b;
	unsigned int RGB;

	printf("RGB값을 하나씩 순서대로 입력(r g b)");
	scanf("%d %d %d",&r,&g,&b);

	r = r%256;
	g = g%256;
	b = b%256;

	RGB = r | (g<<8) | (b<<16);

	printf("RGB값은 \t%06x 입니다",RGB);


}
