#include <stdio.h>


int main(){
	int running_time,hour,minute,second;

	printf("총 소요시간: ");
	scanf("%d", &running_time);

	hour = running_time/3600;
	minute = (running_time%3600)/60;
	second = (running_time%3600)%60;

	printf("재생시간은 ");

	(hour!=0)?printf("%d 시간 ",hour) : printf(" ");
	(minute!=0)?printf("%d 분 ",minute) : printf(" ");
	(second!=0)?printf("%d 초",second) : printf(" ");
	printf("입니다");

}
