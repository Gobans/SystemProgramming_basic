#include <stdio.h>


int main(){
	int sales_rate;
	double favor_rate,exchange_charge,trade_rate, exchange_won,dollar;


	printf("원/달러 매매기준율: ");
	scanf("%d", &sales_rate);

	printf("환전 우대율(0~100%): ");
	scanf("%lf",&favor_rate);

	exchange_charge = sales_rate*0.0175*(1-(favor_rate/100));
	trade_rate = sales_rate + exchange_charge;

	printf("달러를 구매할 떄 환율은 %lf 입니다.",trade_rate);

	printf("구입한 달러(USD): ");
	scanf("%lf",&dollar);

	exchange_won = dollar*trade_rate;
	printf("USD %.2lf 를 살 떄, KRW %.2lf 입니다.",dollar,exchange_won);






}
