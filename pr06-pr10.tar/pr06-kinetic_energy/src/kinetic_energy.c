#include <stdio.h>


int main(){
	double mass,speed,kinetic_energy;
	printf("질량 (kg): ");
	scanf("%lf", &mass);
	printf("속력 (m/s): ");
	scanf("%lf", &speed);

	kinetic_energy = 1.0/2.0*mass*speed*speed;

	printf("운동에너지: 	%.2lf J",kinetic_energy);
}
