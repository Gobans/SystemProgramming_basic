#include <stdio.h>
#include <math.h>

int main(){
	int r;
	double pie = 3.141592, v;

	printf("반지름: ");
	scanf("%d",&r);

	v = 4.0/3.0*pie*pow(r,3);
	printf("구의 부피는 %lf 입니다", v);


}
