#include <stdio.h>

int n_sum(n,sum);

int main(){
	int i, n, sum = 0;

	printf("정수를 입력하시오.: ");
	scanf("%d", &n);

	sum = n_sum(n,sum);


	printf("0부터 %d까지의 합은 %d입니다.\n", n, sum);
	return 0;
}

int n_sum(n,sum){
	for(int i=0; i<=n; i++){
		sum += i;
	}
	return sum;
}
