#include <stdio.h>
#include <math.h>
#define OUTPUT_POW "x의 y 거듭제곱 값은 %d 입니다.\n"


int power();

int main(){
	int x, y;
	printf("두 수를 입력하세요(x y): ");
	scanf("%d%d", &x, &y);
	printf(OUTPUT_POW, power(x, y));
	return 0;
}

int power(int x, int y){
	int sum;
	sum = (int)pow(x,y);
	return sum;
}
