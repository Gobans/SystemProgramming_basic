#include <stdio.h>
#define OUTPUT_SUM "두 수의 합은 %d 입니다.\n"

void get_sum(int a, int b);

int main(){
	int a, b;
	printf("두 수를 입력하세요(a b): ");
	scanf("%d%d", &a, &b);
	get_sum(a, b);
	return 0;
}

void get_sum(int a, int b){
	int sum =  a+b;
	printf(OUTPUT_SUM,sum);

}
