#include <stdio.h>

int main(void){
	float x,y,result;

	x= 85.0;
	y=8.0;
	result = x/y;
	printf("result is %f", result);
	return 0;

}
