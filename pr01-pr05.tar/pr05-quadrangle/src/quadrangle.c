#include <stdio.h>

int main(void){
	double w,h,area,perimeter;
	printf("사각형 두 변의 길이를 입력하세요: ");
	scanf("%lf %lf",&w,&h);
	area = w*2 + h*2;
	perimeter = w*h;
	printf("입력하신 사각형의 둘레는 %lf 이고, 면적은 %lf 입니다.",area,perimeter);
}
