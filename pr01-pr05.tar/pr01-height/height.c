#include <stdio.h>

int main(void){
	printf("나의 키는 170cm입니다");
}
