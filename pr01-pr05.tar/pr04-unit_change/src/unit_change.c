#include <stdio.h>

int main(void){
	const float mile = 1.60934;
	float x;
	printf("마일을 입력하세요: ");
	scanf("%f", &x);
	printf("입력하신 %f mile은 %f km 입니다.",x,mile*x);
	return 0;

}
