#include <stdio.h>

int main(void){
	float x,y,z;
	printf("첫 번째 실수를 입력하세요:");
	scanf("%f", &x);
	printf("두 번째 실수를 입력하세요:");
	scanf("%f", &y);
	printf("세 번째 실수를 입력하세요:");
	scanf("%f", &z);
	printf("합계: %f",x+y+z);
	printf("평균: %f",(x+y+z)/3);

	return 0;

}
