#include <stdio.h>
#define UNIT "단위 가격을 입력하세요: "
#define COUNT "상품 개수를 입력하세요: "
#define TOTAL "총액은 %d원 입니다.\n"

int main(){
	int unit_price, quantity, total_price;
	printf(UNIT);
	scanf("%d", &unit_price);
	printf(COUNT);
	scanf("%d",&quantity);

	if(quantity>10){
		total_price = (unit_price*quantity)*0.95;
	}else{
		total_price = (unit_price*quantity);
	}

	printf(TOTAL,total_price);

}
