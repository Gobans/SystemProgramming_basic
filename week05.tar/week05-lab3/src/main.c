#include <stdio.h>
#define QUERY "Enter gender, age, and weight: "
#define RES "%c, %d, %lf.\n"
#define ERR "Error in input format.\n"

int main(){
	char sex;
	int age,temp;
	double weight;
	// QUERY를 출력한다.

	printf(QUERY);
	// 사용자로부터 입력을 받는다.
	temp = scanf("%c %d %lf",&sex,&age,&weight);
	// 입력받은 과정에서 scanf의 반환 값을 변수에 저장한다.
	// 만약 변수에 저장된 값이 3과 같다면
	if (temp ==3){
		printf(RES,sex,age,weight);
	}else{
		printf(ERR);
	}
		// RES를 출력한다.
	// 그렇지 않다면
		// ERR을 출력한다.
}
