#include <stdio.h>
#define VOWEL "입력하신 문자는 Vowel(자음)입니다.\n"
#define CONSONANT "입력하신 문자는 Consonant(모음)입니다.\n"

int main(){
	char text;
	// 사용자로부터 입력을 받는다.
	printf("문자를 입력해주세요");
	scanf("%c",&text);
	// 만약 사용자의 입력이 자음이라면
	if (text == 'a' || text == 'e' || text == 'i' || text == 'o' || text == 'u' || text == 'A' || text == 'E' || text == 'I' || text == 'O' || text == 'U'){
		printf(VOWEL);
	}
	else{
		printf(CONSONANT);
	}
		// 자음: a 또는 e 또는 i 또는 o 또는 u 또는 A 또는 E 또는I 또는 O 또는 U
		// VOWEL 출력
	// 그렇지 않다면
		// CONSONANAT 출력
}
