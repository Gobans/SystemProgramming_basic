#include <stdio.h>
#define AMOUNT "소비량을 입력해주세요(Kwh): "
#define SEASON "여름이나 겨울일 경우 1, 아니면 0을 입력해주세요: "
#define RESULT "세금을 포함한 금액은 %d원 입니다."

int main(){
	int kwh,season,result;
	printf(AMOUNT);
	scanf("%d",&kwh);
	printf(SEASON);
	scanf("%d",&season);

	if(kwh<=200){
		result = 910 + 93.3*kwh;
	}
	else if(201<=kwh && kwh <=400){
		result = 1600 +187.9*kwh;
	}
	else{
		if(season && kwh > 1000){
			result = 7300 + 709.5*kwh;
		}else{
			result = 7300 + 280.6*kwh;
		}
	}

	result = result*1.137;
	printf(RESULT,result);

}
