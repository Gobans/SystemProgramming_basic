#include <stdio.h>
#define QUERY "Enter a character: "
#define ALPHA "It is an alphabet.\n"
#define DIGIT "It is a digit.\n"
#define OTHER "It is neither an alphabet nor a digit.\n"

int main(){
	char text;
	// 사용자로부터 입력을 받는다.
	printf(QUERY);
	scanf("%c",&text);
	if(48<=text && text<=57){
		printf(DIGIT);
	}
	else if(65<=text && text<=90 || 97<= text && text<=122){
		printf(ALPHA);
	}
	else{
		printf(OTHER);
	}
	// 입력 값의 범위를 확인한다.
	// 만약 숫자의 범위에 포함된다면 DIGIT 출력
	// 그렇지 않고 만약 문자의 범위에 포함된다면 ALPHA 출력
	// 그렇지 않다면 OTHER 출력
}
