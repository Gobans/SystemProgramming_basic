#include <stdio.h>
#define INPUT1 "(1,3,5,7,9,11,15,17,19,21,23,25)\n위의 숫자 중 하나를 입력하시오: "
#define INPUT2 "0 ~ 25 사이의 숫자 중 하나를 입력하시오: "
#define INPUT3 "암호화할 문장을 입력하시오: "

int main(){
	int key1, key2;
	char ch;
	printf(INPUT1);
	scanf("%d",&key1);
	printf(INPUT2);
	scanf("%d",&key2);
	getchar();

	printf(INPUT3);
	while((ch = getchar()) != '\n'){
		if(ch ==' ') continue;
		ch -= 'a';
		ch *=key1;
		ch +=key2;
		ch %=26;
		ch += 'a';
		printf("%c", ch);
	}
	return 0;
}
