#include <stdio.h>
#define INPUT "숫자를 입력하세요: "
#define OUTPUT "덧셈의 결과는 %d입니다.\n"

int main(){
	int num , sum=0;
	while(1){
		printf(INPUT);
		scanf("%d",&num);
		if (num == 0){
			break;
		}
		sum += num;
	}
	printf(OUTPUT,sum);
	return 0;
}
