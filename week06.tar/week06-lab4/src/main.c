#include <stdio.h>
#define INPUT "높이를 입력하세요: "

int main(){
	int height, i,space,j,k;
	printf(INPUT);
	scanf("%d",&height);

	for(i=1; i<=height; i++){
		for(space = 0; space<height-i; space++){
			printf(" ");
		}
		for(j=1; j<=i; j++){
			printf("*");
		}

		for(k=1; k<i; k++){
			printf("*");
		}

		printf("\n");
	}
	return 0;
}
