#include <stdio.h>
#define INPUT1 "출력할 단을 입력하세요: "
#define INPUT2 "출력할 줄의 수를 입력하세요: "
#define OUTPUT "%d x %d = %d\n"

int main(){
	int num1 , num2,i;
	printf(INPUT1);
	scanf("%d",&num1);
	printf(INPUT2);
	scanf("%d",&num2);
	for(i=1; i<=num2; i++){
		printf(OUTPUT,num1,i,num1*i);

	}
	return 0;
}
